/*
 * Add the include files that you need. "man" can help you find them.
 * You will probably need stdio.h for printf and fprintf
 */
#include <stdio.h>
#include <string.h>
#include "stringops-todo.h"
#include <ctype.h> //For å kunne bruke tolower. Antar at dette er ok å bruke i denne obligen. 



int   stringsum( char *s )
{
    int size = strlen(s);
    int sum = 0;

    for (int i = 0; i<size; i++){
        if(s[i] == ' '){
            continue;                           
        } else if (isdigit(s[i])) return -1;    
                   
        
        char lower = tolower(s[i]);             
        int value = lower - 'a' + 1;            //'a' tilsvarer ASCII verdien til bokstaven a. Ved å trekke denne fra ascii verdien til karakteren s[i], får vi den alfabetiske verdien.  
                                                //Dette er fordi bokstavene ligger numerisk sortert i ascii tabellen også 
        sum += value;
    }

    return sum;
}


int   distance_between( char *s, char c )
{
    int size = strlen(s);

    int firstPos = -1;
    int lastPos = -1;

    for(int i = 0; i<size; i++){
        if(s[i] == c){
            if (firstPos == -1){
                firstPos = i;
            } else lastPos = i;  
        } 
    }

    if(firstPos == -1){
        return -1;
    }else if (lastPos == -1){
        return 0;
    } else return lastPos - firstPos;
    
}

char* string_between( char *s, char c )
{

    int size = strlen(s);
    int first = -1;
    int last = -1;

    for(int i = 0; i<size; i++){
        if (s[i] == c){
            if (first == -1){
                first = i;
                s = s+i+1;
            } else last = i;  
        }
    }

    if (first == -1){
        return NULL;
    } else if (last == -1) {
        return "";
    } else{
        s[last] = '\0';  
        return s;
    }

    
}

int  stringsum2( char *s, int *res )
{
    //Jeg antar at det er greit at jeg bruker stringsum funksjonen fra oppgave a) her, siden det ikke er spesifisert i oppgaven at jeg ikke kan det.
    *res = stringsum(s);

    if(*res > 0){
        return 0;
    }

    return -1;
  
  
}


